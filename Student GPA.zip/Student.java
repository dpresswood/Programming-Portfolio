/* File: Project4
 * Author: Deanna M. Presswood
 * Date: July 13, 2017
 * Purpose: This program manages a student database.
 */
package project4;

import java.text.DecimalFormat;
   
    //The 2nd class is named Student, it defines the student record.
   // Name and major variable created for each Student.
   public class Student {
       private String name;
       private String major;
  
        //Doubles to calculate gpa
        private double credits;
        private double totalPoints;
  
            //Default constructor
            public Student() {
                name = "Name";
                major = "Major";
                credits = 0;
                totalPoints = 0;
            } //End default constructor
  
                // Constructor which takes in a name and major, sets credits and 
                //and points to 0.
                public Student(String name, String major) {
                    this.name = name;
                    this.major = major;
                    credits = 0;
                    totalPoints = 0;
                } // End name and major constructor
  
                    // 2nd method accepts the course grade and credit hours.
                    // Method also updates the variables used to compute the GPA.
                    public void courseCompleted(String grade, int hours) {
                        credits += hours;
      
                        switch(grade.toLowerCase().charAt(0)) {
                            case 'a':
                                totalPoints += 4 * hours;
                                break;
                            case 'b':
                                totalPoints += 3 * hours;
                                break;
                            case 'c':
                                totalPoints += 2 * hours;
                                break;
                            case 'd':
                                totalPoints += hours;
                                break;
                            default:
                                break;
                        } //End switch
                    } //End courseCompleted method
  
                        //3rd method overide toString and returns Student's information
                        @Override
                        public String toString() {
                            //Format gpa to two decimal places in calculation
                            DecimalFormat formatter = new DecimalFormat("#0.00");
                            //Default gpa if student's class information hasn't been updated yet
                            String gpa = "4.0";

                            //Calculate gpa 
                            if(credits > 0) {
                                gpa = formatter.format(totalPoints / credits);
                            }

                            //String to return student's information as a String
                            String studentInfo = "Name: " + name +
                                    "\nMajor: " + major + "\nGPA: " + gpa;
                            return studentInfo;
                        } //End toString method
                     } //End class
