/*
* File: Project4
 * Author: Deanna M. Presswood
 * Date: July 13, 2017
 * Purpose: This program manages a student database. 
 */
package project4;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;


    //The 1st class defines the GUI and handles the database interactions.
    public class StudentGUI extends JFrame implements ActionListener {
    //Database action options
    private String[] operationPerformed = {"Insert", "Delete", "Update", "Find"};
    // Create the combo box
    private JComboBox operationTypes = new JComboBox(operationPerformed);
    private JButton processButton = new JButton("Process Request");
    private JTextField nameField = new JTextField();
    private JTextField idField = new JTextField();
    private JTextField majorField = new JTextField();
    //Create a HashMap
    private HashMap <String, Student> resultMap = new HashMap<String, Student>();

    
    public StudentGUI(){
        //Set up frame
        super("Student");
        setLayout(new GridLayout(0, 2));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        operationTypes.addActionListener(this);
       
        ///Create Text labels
        add(new JLabel("ID: "));
        add(idField);

        add(new JLabel("Name: "));
        add(nameField);

        add(new JLabel("Major: "));
        add(majorField);

        add(new JLabel("Choose Selection: "));
        add(operationTypes);
        
        add(processButton);
        processButton.addActionListener(this);
        setBoxes(true, true, true);
        pack();
        setVisible(true);
    }

        void setBoxes(boolean idState, boolean nameState, boolean majorState) {
            idField.setEditable(idState);
            nameField.setEditable(nameState);
            majorField.setEditable(majorState);
                if (!idState) {
                    idField.setText("");
                }
                if (!nameState) {
                    nameField.setText("");
                }
                if (!majorState) {
                    majorField.setText("");
                }
        }

            public static void main(String[] args) {
                new StudentGUI();
            }

                @Override
                // ActionPerformed method implementation
                public void actionPerformed(ActionEvent evt) {
                    int command = operationTypes.getSelectedIndex();
                    if (evt.getSource() == operationTypes) {

                    if (command == 0) {
                        setBoxes(true, true, true);
                    } else {
                        setBoxes(true, false, false);
                    }
                    } else if (evt.getSource() == processButton) {
                        String strId = getSafeString(idField.getText());
                    if (strId.length() == 0) {
                        displayMessage("Enter ID Field");
                        return;
                    }
                    if (command == 0) {
                    if (resultMap.containsKey(strId)) {
                        displayMessage("Student with this ID already exists in database.");
                    return;
                    }
                        String strName = getSafeString(nameField.getText());
                        String strMajor = getSafeString(majorField.getText());
                    if (strName.length() == 0) {
                        displayMessage("Enter Name");
                        return;
                    }
                    if (strMajor.length() == 0) {
                        displayMessage("Enter Major");
                        return;
                    }
                        resultMap.put(strId, new Student(strName, strMajor));
                        displayMessage("Student information added");
                    } else {
                    if (!resultMap.containsKey(strId)) {
                        displayMessage("Student ID not found in database.");
                        return;
                    }
                    //"Delete" and "Find"
                    if (command == 1) {
                        Student stu = resultMap.get(strId);
                        resultMap.remove(strId);
                        displayMessage("Student deleted: " + stu.toString());
                    } else if (command == 3) {
                        Student stu = resultMap.get(strId);
                        displayMessage("Student found: " + stu.toString());
                    } else if (command == 2) {
                    

                        String[] choices = {"A", "B", "C", "D", "E", "F"};
                        String grade = (String) JOptionPane.showInputDialog(null, 
                            "Choose grade: ","Choose grade", 
                            JOptionPane.QUESTION_MESSAGE, null, 
                            
                            choices, // Array of choices
                            choices[0]); // Initial choice

                            choices = new String[]{"3", "6"};
                            int credits = Integer.parseInt((String) 
                            JOptionPane.showInputDialog(null, "Choose credits: ",
                            "Choose credits", JOptionPane.QUESTION_MESSAGE, null, 
                            
                            choices, // Array of choices
                            choices[0])); // Initial choice
                   
                            Student stu = resultMap.get(strId);
                            stu.courseCompleted(grade, ABORT);
                            displayMessage("Student information updated: " + stu.toString());
                    }
                }
            }
        }

                        public void displayMessage(String stu) {
                            JOptionPane.showMessageDialog(null, stu);
                        }

                            //Return blank string if null
                            public String getSafeString(String stu) {
                                if (stu == null) {
                                    return stu;
                                }
                                    return stu.trim();
                            }

    
                                public int getInt(String msg) {
                                    int num = 0;
                                    boolean positive = true;
                                        do {
                                            positive = true;
                                        try {
                                            num = Integer.parseInt(JOptionPane.showInputDialog(msg));
                                        if (num <= 0) {
                                            positive = false;
                                            displayMessage("Enter positive numeric value");
                                        }
                                        } catch (Exception evt) {
                                            positive = false;
                                            displayMessage("Enter positive numeric value");
                                        }
                                        } while (!positive);
                                            return num;
                                }
}
