/*
Date:  June 30, 2018 
Author: Deanna M. Presswood 
Title: Login App Test
Description: Four Login Application JUnit Test Cases.

 */
package sdev460;

import java.text.SimpleDateFormat;
import javafx.stage.Stage;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author The Presswood's
 */
public class loginAppTest {
    
    public loginAppTest() {
    }
    

    /**
     * Test of authenticate method, of class loginApp.
     */
    @Test
    public void testAuthenticate() {
        System.out.println("authenticate");
        String user = "";
        String pword = "";
        loginApp instance = new loginApp();
        boolean expResult = false;
        boolean result = instance.authenticate(user, pword);
        //test Username "Admin" and Password "password"
        assertEquals(expResult, result);
        
    }

      /**
     * Test of authenticate method, of class loginApp.
     */
    @Test
    public void testAuthenticate2() {
        System.out.println("authenticate");
        String user = "";
        String pword = "";
        loginApp instance = new loginApp();
        boolean expResult = true;
        boolean result = instance.authenticate(user, pword);
        //test Username "Admin" and Password "password"
        assertEquals(expResult, result);
        
    }
    /**
     * Test of accessLog method, of class loginApp.
     */
    @Test
    public void testAccessLog() {
        //create an instance to test 
        testLoginApp testloginapp = new testLoginApp();
        System.out.println("accessLog");
        String username = "";
        boolean isValid = false;
        loginApp.accessLog(username, isValid);
        //test Username 
       assertFalse(username, isValid);
    }
    @Test
    public void testAccessLog2() {
        //create an instance to test 
        testLoginApp testloginapp = new testLoginApp();
        assertNotNull(testloginapp);
}
}