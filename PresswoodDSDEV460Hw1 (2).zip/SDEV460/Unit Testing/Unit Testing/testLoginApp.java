/*
Date:  June 30, 2018 
Author: Deanna M. Presswood 
Title: Login App Test
Description: Test method for loginAppTest

 */
package sdev460;

/**
 *
 * @author The Presswood's
 */
class testLoginApp {
    
}
